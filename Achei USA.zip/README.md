# Achei-USA-Roku
This is a Roku Channel that lists videos in the Roku Rowlist. On selecting any item in the list the details of the video will be visible to the User, with an option to play the selected video. This Roku Channel also demonstrates Deeplink integration in Roku.
